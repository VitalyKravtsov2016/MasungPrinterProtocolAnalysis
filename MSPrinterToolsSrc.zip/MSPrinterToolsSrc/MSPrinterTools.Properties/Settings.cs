using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace MSPrinterTools.Properties;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "9.0.0.0")]
internal sealed class Settings : ApplicationSettingsBase
{
	private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

	public static Settings Default => defaultInstance;

	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	[UserScopedSetting]
	public string language
	{
		get
		{
			return (string)this["language"];
		}
		set
		{
			this["language"] = value;
		}
	}

	[DefaultSettingValue("True")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public bool FirstTime
	{
		get
		{
			return (bool)this["FirstTime"];
		}
		set
		{
			this["FirstTime"] = value;
		}
	}

	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public string LanguageSet
	{
		get
		{
			return (string)this["LanguageSet"];
		}
		set
		{
			this["LanguageSet"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("-1")]
	[DebuggerNonUserCode]
	public int PortTab
	{
		get
		{
			return (int)this["PortTab"];
		}
		set
		{
			this["PortTab"] = value;
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	[UserScopedSetting]
	public string setIP
	{
		get
		{
			return (string)this["setIP"];
		}
		set
		{
			this["setIP"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setPort
	{
		get
		{
			return (string)this["setPort"];
		}
		set
		{
			this["setPort"] = value;
		}
	}

	[DefaultSettingValue("0")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public int Bandrate
	{
		get
		{
			return (int)this["Bandrate"];
		}
		set
		{
			this["Bandrate"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string setWifiWan
	{
		get
		{
			return (string)this["setWifiWan"];
		}
		set
		{
			this["setWifiWan"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("0")]
	public int wifiModel
	{
		get
		{
			return (int)this["wifiModel"];
		}
		set
		{
			this["wifiModel"] = value;
		}
	}

	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public string setWifiIPAddr
	{
		get
		{
			return (string)this["setWifiIPAddr"];
		}
		set
		{
			this["setWifiIPAddr"] = value;
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	[UserScopedSetting]
	public string setWifiMask
	{
		get
		{
			return (string)this["setWifiMask"];
		}
		set
		{
			this["setWifiMask"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string setWifiGateway
	{
		get
		{
			return (string)this["setWifiGateway"];
		}
		set
		{
			this["setWifiGateway"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string setWifiSubscribe1
	{
		get
		{
			return (string)this["setWifiSubscribe1"];
		}
		set
		{
			this["setWifiSubscribe1"] = value;
		}
	}

	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public string setWifiPublish1
	{
		get
		{
			return (string)this["setWifiPublish1"];
		}
		set
		{
			this["setWifiPublish1"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	public string setWifiMQTTPort
	{
		get
		{
			return (string)this["setWifiMQTTPort"];
		}
		set
		{
			this["setWifiMQTTPort"] = value;
		}
	}

	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public string setWifiMQTTIP
	{
		get
		{
			return (string)this["setWifiMQTTIP"];
		}
		set
		{
			this["setWifiMQTTIP"] = value;
		}
	}

	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	[UserScopedSetting]
	public string setWifiClientPassword
	{
		get
		{
			return (string)this["setWifiClientPassword"];
		}
		set
		{
			this["setWifiClientPassword"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setWifiClientID
	{
		get
		{
			return (string)this["setWifiClientID"];
		}
		set
		{
			this["setWifiClientID"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string setWifiClientName
	{
		get
		{
			return (string)this["setWifiClientName"];
		}
		set
		{
			this["setWifiClientName"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setWifiPassword
	{
		get
		{
			return (string)this["setWifiPassword"];
		}
		set
		{
			this["setWifiPassword"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setWifiDNS
	{
		get
		{
			return (string)this["setWifiDNS"];
		}
		set
		{
			this["setWifiDNS"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("200")]
	public string SpeedCount
	{
		get
		{
			return (string)this["SpeedCount"];
		}
		set
		{
			this["SpeedCount"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string SpeedData
	{
		get
		{
			return (string)this["SpeedData"];
		}
		set
		{
			this["SpeedData"] = value;
		}
	}

	[UserScopedSetting]
	[DefaultSettingValue("")]
	[DebuggerNonUserCode]
	public string setWifiPublish2
	{
		get
		{
			return (string)this["setWifiPublish2"];
		}
		set
		{
			this["setWifiPublish2"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setWifiPublish3
	{
		get
		{
			return (string)this["setWifiPublish3"];
		}
		set
		{
			this["setWifiPublish3"] = value;
		}
	}

	[DebuggerNonUserCode]
	[DefaultSettingValue("")]
	[UserScopedSetting]
	public string setWifiSubscribe2
	{
		get
		{
			return (string)this["setWifiSubscribe2"];
		}
		set
		{
			this["setWifiSubscribe2"] = value;
		}
	}

	[DefaultSettingValue("")]
	[UserScopedSetting]
	[DebuggerNonUserCode]
	public string setWifiSubscribe3
	{
		get
		{
			return (string)this["setWifiSubscribe3"];
		}
		set
		{
			this["setWifiSubscribe3"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("127.0.0.1")]
	public string PrintConnValue2
	{
		get
		{
			return (string)this["PrintConnValue2"];
		}
		set
		{
			this["PrintConnValue2"] = value;
		}
	}

	private void SettingChangingEventHandler(object sender, SettingChangingEventArgs e)
	{
	}

	private void SettingsSavingEventHandler(object sender, CancelEventArgs e)
	{
	}
}
