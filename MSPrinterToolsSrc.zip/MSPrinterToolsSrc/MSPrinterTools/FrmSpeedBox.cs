using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace MSPrinterTools;

public class FrmSpeedBox : Form
{
	private delegate void delegateUpdateRecvText2(int iNum, string str);

	private int m_iSpeedTimer = 0;

	private IContainer components = null;

	private Label label1;

	private Button button1;

	private Label lblSpeed;

	private Label label3;

	private Label label5;

	private Timer timer1;

	private Label label49;

	private Label m_lblSpeed;

	public FrmSpeedBox()
	{
		InitializeComponent();
	}

	public void UpdateRecvText2(int iNum, string str)
	{
		try
		{
			Invoke((delegateUpdateRecvText2)delegate(int Nums, string strstr)
			{
				timer1.Enabled = false;
				int num = (int)((double)Nums * 3.75 / (double)m_iSpeedTimer * 1.01 * 10.0);
				lblSpeed.Text = num + "mm/S";
			}, iNum, str);
		}
		catch (Exception)
		{
		}
	}

	public void button1_Click(object sender, EventArgs e)
	{
		Close();
	}

	private void timer1_Tick(object sender, EventArgs e)
	{
		m_iSpeedTimer++;
		m_lblSpeed.Text = string.Format("{1:D2}:{2:D2}.{3}", m_iSpeedTimer / 36000, m_iSpeedTimer / 600 % 60, m_iSpeedTimer / 10 % 60, m_iSpeedTimer % 10);
	}

	private void FrmSpeedBox_Load(object sender, EventArgs e)
	{
		lblSpeed.Text = "";
		m_iSpeedTimer = 0;
		timer1.Enabled = true;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	public void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MSPrinterTools.FrmSpeedBox));
		this.label1 = new System.Windows.Forms.Label();
		this.button1 = new System.Windows.Forms.Button();
		this.lblSpeed = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.label5 = new System.Windows.Forms.Label();
		this.timer1 = new System.Windows.Forms.Timer(this.components);
		this.label49 = new System.Windows.Forms.Label();
		this.m_lblSpeed = new System.Windows.Forms.Label();
		base.SuspendLayout();
		resources.ApplyResources(this.label1, "label1");
		this.label1.Name = "label1";
		resources.ApplyResources(this.button1, "button1");
		this.button1.Name = "button1";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		resources.ApplyResources(this.lblSpeed, "lblSpeed");
		this.lblSpeed.Name = "lblSpeed";
		resources.ApplyResources(this.label3, "label3");
		this.label3.Name = "label3";
		resources.ApplyResources(this.label5, "label5");
		this.label5.Name = "label5";
		this.timer1.Tick += new System.EventHandler(timer1_Tick);
		resources.ApplyResources(this.label49, "label49");
		this.label49.Name = "label49";
		resources.ApplyResources(this.m_lblSpeed, "m_lblSpeed");
		this.m_lblSpeed.Name = "m_lblSpeed";
		resources.ApplyResources(this, "$this");
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.Controls.Add(this.label49);
		base.Controls.Add(this.m_lblSpeed);
		base.Controls.Add(this.label5);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.lblSpeed);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.label1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
		base.Name = "FrmSpeedBox";
		base.Load += new System.EventHandler(FrmSpeedBox_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
