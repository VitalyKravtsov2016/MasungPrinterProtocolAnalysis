using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace MSPrinterTools;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
public class String_zh_CN
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static ResourceManager ResourceManager
	{
		get
		{
			if (object.ReferenceEquals(resourceMan, null))
			{
				ResourceManager resourceManager = new ResourceManager("MSPrinterTools.String_zh-CN", typeof(String_zh_CN).Assembly);
				resourceMan = resourceManager;
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	public static string R10001 => ResourceManager.GetString("R10001", resourceCulture);

	public static string R10002 => ResourceManager.GetString("R10002", resourceCulture);

	public static string R10003 => ResourceManager.GetString("R10003", resourceCulture);

	public static string R10004 => ResourceManager.GetString("R10004", resourceCulture);

	public static string R10005 => ResourceManager.GetString("R10005", resourceCulture);

	public static string R10006 => ResourceManager.GetString("R10006", resourceCulture);

	public static string R10007 => ResourceManager.GetString("R10007", resourceCulture);

	public static string R10008 => ResourceManager.GetString("R10008", resourceCulture);

	public static string R10009 => ResourceManager.GetString("R10009", resourceCulture);

	public static string R10010 => ResourceManager.GetString("R10010", resourceCulture);

	public static string R10011 => ResourceManager.GetString("R10011", resourceCulture);

	public static string R10012 => ResourceManager.GetString("R10012", resourceCulture);

	public static string R10013 => ResourceManager.GetString("R10013", resourceCulture);

	public static string R10014 => ResourceManager.GetString("R10014", resourceCulture);

	public static string R10015 => ResourceManager.GetString("R10015", resourceCulture);

	public static string R10016 => ResourceManager.GetString("R10016", resourceCulture);

	public static string R10017 => ResourceManager.GetString("R10017", resourceCulture);

	public static string R10018 => ResourceManager.GetString("R10018", resourceCulture);

	public static string R10019 => ResourceManager.GetString("R10019", resourceCulture);

	public static string R10020 => ResourceManager.GetString("R10020", resourceCulture);

	public static string R10021 => ResourceManager.GetString("R10021", resourceCulture);

	public static string R10022 => ResourceManager.GetString("R10022", resourceCulture);

	public static string R10023 => ResourceManager.GetString("R10023", resourceCulture);

	public static string R10024 => ResourceManager.GetString("R10024", resourceCulture);

	public static string R10025 => ResourceManager.GetString("R10025", resourceCulture);

	public static string R10026 => ResourceManager.GetString("R10026", resourceCulture);

	public static string R10027 => ResourceManager.GetString("R10027", resourceCulture);

	public static string R10028 => ResourceManager.GetString("R10028", resourceCulture);

	public static string R10029 => ResourceManager.GetString("R10029", resourceCulture);

	public static string R10030 => ResourceManager.GetString("R10030", resourceCulture);

	public static string R10031 => ResourceManager.GetString("R10031", resourceCulture);

	public static string R10032 => ResourceManager.GetString("R10032", resourceCulture);

	public static string R10033 => ResourceManager.GetString("R10033", resourceCulture);

	public static string R10034 => ResourceManager.GetString("R10034", resourceCulture);

	public static string R10035 => ResourceManager.GetString("R10035", resourceCulture);

	internal String_zh_CN()
	{
	}
}
