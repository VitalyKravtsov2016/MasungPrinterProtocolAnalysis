using System;
using System.Resources;
using System.Text.RegularExpressions;

namespace MSPrinterTools;

internal class Utility
{
	private static ResXResourceSet m_resx_en_US;

	private static ResXResourceSet m_resx_zh_CN;

	private static int m_iResxLoad = 0;

	public static int StrintResInit()
	{
		int result = -1;
		try
		{
			m_resx_en_US = new ResXResourceSet("String_en-US.resx");
			m_resx_zh_CN = new ResXResourceSet("String_zh-CN.resx");
			m_iResxLoad = 1;
			result = 0;
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
		}
		return result;
	}

	public static string GetStringRes(string strID, string strDefault, string strLanguage)
	{
		string text = "";
		try
		{
			if (m_iResxLoad == 0)
			{
				StrintResInit();
			}
			text = ((!(strLanguage == GlobalVar.g_str_Language_zh_CHS)) ? m_resx_en_US.GetString(strID.ToUpper()) : m_resx_zh_CN.GetString(strID.ToUpper()));
			if (text == "" || text == null)
			{
				text = strDefault;
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
		}
		return text;
	}

	public static byte[] StrToHexByte(string hexString)
	{
		int length = hexString.Length;
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		string text = hexString.Trim();
		string text2 = "";
		string text3 = "";
		string text4 = "";
		if (text.IndexOf(" ") > 0)
		{
			text = text.Replace("\r\n", " ");
			if (length > 16384)
			{
				text2 = text;
				text2 = text2.Replace(" ", "");
			}
			else
			{
				text += " ";
				while (text.Trim().Length != 0)
				{
					num2 = text.IndexOf(" ");
					if (num2 <= 0)
					{
						continue;
					}
					text3 = text.Substring(0, num2);
					if (text3.Length > 2)
					{
						text4 = Regex.Replace(text3, "\\s", "");
						if (text4.Length % 2 != 0)
						{
							throw new Exception("Data format error!");
						}
						text3 = "";
						num3 = text4.Length / 2;
						for (num = 0; num < num3; num++)
						{
							text3 = text3 + " " + text4.Substring(num * 2, 2);
						}
					}
					else if (text3.Length == 1)
					{
						text3 = "0" + text3;
					}
					text2 += text3;
					text = text.Substring(num2).TrimStart();
				}
			}
		}
		else
		{
			text2 = text;
		}
		text2 = Regex.Replace(text2, "\\s", "");
		if (text2.Length % 2 != 0)
		{
			text2 += " ";
		}
		byte[] array = new byte[text2.Length / 2];
		for (num = 0; num < array.Length; num++)
		{
			array[num] = Convert.ToByte(text2.Substring(num * 2, 2), 16);
		}
		return array;
	}
}
