using System;
using System.ComponentModel;
using System.Windows.Forms;
using Liang.LanguageLibrary;

namespace MSPrinterTools;

public class FrmPrintingBox : Form
{
	private delegate void delegateUpdateRecvText2(int iNum, string str);

	private IContainer components = null;

	private Label label1;

	private Button button1;

	private Label label2;

	private Label label3;

	private Label label4;

	private Label label5;

	private Label label6;

	public FrmPrintingBox()
	{
		InitializeComponent();
	}

	public int FreshControl()
	{
		SetLanguage.SetLang(user1.m_strLanguage, this, typeof(FrmPrintingBox));
		label2.Text = user1.Ptintimes.ToString();
		label2.Refresh();
		return 1;
	}

	public void UpdateRecvText2(int iNum, string str)
	{
		try
		{
			Invoke((delegateUpdateRecvText2)delegate(int Nums, string strstr)
			{
				FreshControl();
				switch (Nums)
				{
				case 1:
					label3.Text = strstr;
					break;
				case 2:
					label1.Text = strstr;
					break;
				default:
					button1.Text = strstr;
					break;
				}
			}, iNum, str);
		}
		catch (Exception)
		{
		}
	}

	public void button1_Click(object sender, EventArgs e)
	{
		user1.m_Switch = false;
		Close();
	}

	private void FrmPrintingBox_Load(object sender, EventArgs e)
	{
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	public void InitializeComponent()
	{
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MSPrinterTools.FrmPrintingBox));
		this.label1 = new System.Windows.Forms.Label();
		this.button1 = new System.Windows.Forms.Button();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.label4 = new System.Windows.Forms.Label();
		this.label5 = new System.Windows.Forms.Label();
		this.label6 = new System.Windows.Forms.Label();
		base.SuspendLayout();
		this.label1.AccessibleDescription = null;
		this.label1.AccessibleName = null;
		resources.ApplyResources(this.label1, "label1");
		this.label1.Font = null;
		this.label1.Name = "label1";
		this.button1.AccessibleDescription = null;
		this.button1.AccessibleName = null;
		resources.ApplyResources(this.button1, "button1");
		this.button1.BackgroundImage = null;
		this.button1.Font = null;
		this.button1.Name = "button1";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.label2.AccessibleDescription = null;
		this.label2.AccessibleName = null;
		resources.ApplyResources(this.label2, "label2");
		this.label2.Font = null;
		this.label2.Name = "label2";
		this.label3.AccessibleDescription = null;
		this.label3.AccessibleName = null;
		resources.ApplyResources(this.label3, "label3");
		this.label3.Font = null;
		this.label3.Name = "label3";
		this.label4.AccessibleDescription = null;
		this.label4.AccessibleName = null;
		resources.ApplyResources(this.label4, "label4");
		this.label4.Font = null;
		this.label4.Name = "label4";
		this.label5.AccessibleDescription = null;
		this.label5.AccessibleName = null;
		resources.ApplyResources(this.label5, "label5");
		this.label5.Font = null;
		this.label5.Name = "label5";
		this.label6.AccessibleDescription = null;
		this.label6.AccessibleName = null;
		resources.ApplyResources(this.label6, "label6");
		this.label6.Font = null;
		this.label6.Name = "label6";
		base.AccessibleDescription = null;
		base.AccessibleName = null;
		resources.ApplyResources(this, "$this");
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackgroundImage = null;
		base.Controls.Add(this.label6);
		base.Controls.Add(this.label5);
		base.Controls.Add(this.label4);
		base.Controls.Add(this.label3);
		base.Controls.Add(this.label2);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.label1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		base.Icon = null;
		base.Name = "FrmPrintingBox";
		base.Load += new System.EventHandler(FrmPrintingBox_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
