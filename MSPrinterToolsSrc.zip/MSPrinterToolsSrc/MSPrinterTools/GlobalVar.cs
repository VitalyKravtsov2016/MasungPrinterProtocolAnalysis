namespace MSPrinterTools;

internal class GlobalVar
{
	public static string g_str_Language_zh_CHS = "zh-CHS";

	public static string g_str_Language_en_US = "en-US";
}
