using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace MSPrinterTools;

public static class Win32Utility
{
	private struct COMBOBOXINFO
	{
		public int cbSize;

		public RECT rcItem;

		public RECT rcButton;

		public IntPtr stateButton;

		public IntPtr hwndCombo;

		public IntPtr hwndItem;

		public IntPtr hwndList;
	}

	private struct RECT
	{
		public int left;

		public int top;

		public int right;

		public int bottom;
	}

	private const int EM_SETCUEBANNER = 5377;

	private const int EM_GETCUEBANNER = 5378;

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

	[DllImport("user32.dll")]
	private static extern bool SendMessage(IntPtr hwnd, int msg, int wParam, StringBuilder lParam);

	[DllImport("user32.dll")]
	private static extern bool GetComboBoxInfo(IntPtr hwnd, ref COMBOBOXINFO pcbi);

	public static void SetCueText(Control control, string text)
	{
		if (control is ComboBox)
		{
			SendMessage(GetComboBoxInfo(control).hwndItem, 5377, 0, text);
		}
		else
		{
			SendMessage(control.Handle, 5377, 0, text);
		}
	}

	private static COMBOBOXINFO GetComboBoxInfo(Control control)
	{
		COMBOBOXINFO pcbi = default(COMBOBOXINFO);
		pcbi.cbSize = Marshal.SizeOf(pcbi);
		GetComboBoxInfo(control.Handle, ref pcbi);
		return pcbi;
	}

	public static string GetCueText(Control control)
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (control is ComboBox)
		{
			COMBOBOXINFO pcbi = default(COMBOBOXINFO);
			pcbi.cbSize = Marshal.SizeOf(pcbi);
			GetComboBoxInfo(control.Handle, ref pcbi);
			SendMessage(pcbi.hwndItem, 5378, 0, stringBuilder);
		}
		else
		{
			SendMessage(control.Handle, 5378, 0, stringBuilder);
		}
		return stringBuilder.ToString();
	}
}
