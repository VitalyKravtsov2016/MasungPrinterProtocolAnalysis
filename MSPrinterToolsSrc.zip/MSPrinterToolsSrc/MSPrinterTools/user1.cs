namespace MSPrinterTools;

internal class user1
{
	public static int Ptintimes;

	public static bool m_Switch = false;

	public static string m_strLanguage = "";
}
