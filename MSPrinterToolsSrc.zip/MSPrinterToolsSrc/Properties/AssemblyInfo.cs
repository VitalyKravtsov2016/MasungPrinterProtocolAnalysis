using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

[assembly: Guid("e4669b4e-bde6-4d77-959e-1cf812a4089b")]
[assembly: ComVisible(false)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyTitle("MSPrinterTools")]
[assembly: AssemblyFileVersion("1.0.1.8")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("MSPrinterTools")]
[assembly: AssemblyCopyright("Copyright ©  2023")]
[assembly: AssemblyVersion("1.0.1.8")]
