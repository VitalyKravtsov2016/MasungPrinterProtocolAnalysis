using System;
using System.ComponentModel;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace Liang.LanguageLibrary;

public class SetLanguage
{
	public static void SetLang(string lang, Form form, Type frmtype)
	{
		Thread.CurrentThread.CurrentUICulture = new CultureInfo(lang);
		if (form != null)
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(frmtype);
			componentResourceManager.ApplyResources(form, "$this");
			AppLang(form, componentResourceManager);
		}
	}

	public static bool IsChineseSimple()
	{
		return Thread.CurrentThread.CurrentCulture.Name == "zh-CN";
	}

	private static void AppLang(Control control, ComponentResourceManager resources)
	{
		if (control is MenuStrip)
		{
			resources.ApplyResources(control, control.Name);
			MenuStrip menuStrip = (MenuStrip)control;
			if (menuStrip.Items.Count > 0)
			{
				foreach (ToolStripMenuItem item in menuStrip.Items)
				{
					AppLang(item, resources);
				}
			}
		}
		foreach (Control control2 in control.Controls)
		{
			resources.ApplyResources(control2, control2.Name);
			AppLang(control2, resources);
		}
	}

	private static void AppLang(ToolStripMenuItem item, ComponentResourceManager resources)
	{
		if (item == null)
		{
			return;
		}
		resources.ApplyResources(item, item.Name);
		if (item.DropDownItems.Count <= 0)
		{
			return;
		}
		foreach (ToolStripMenuItem dropDownItem in item.DropDownItems)
		{
			AppLang(dropDownItem, resources);
		}
	}
}
